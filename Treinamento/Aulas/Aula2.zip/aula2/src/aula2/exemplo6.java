package aula2;

public class exemplo6 {

	public static void main(String[] args) {
		
		int idade = 18; 
		boolean amigoDoDono = true; 
		if 
		(idade < 18 && amigoDoDono == false) 
		{ System.out.println("N�o pode entrar"); } 
		else 
		{ System.out.println("Pode entrar"); } 
	}
}
