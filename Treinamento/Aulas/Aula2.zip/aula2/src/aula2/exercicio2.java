package aula2;

import javax.swing.JOptionPane;

public class exercicio2 {

	public static void main(String[] args) {

			String a,s,n;
			float salario=1500;
			float saldo=500;	
			float c,d,e;
			
			a = JOptionPane.showInputDialog("Digite o valor do saque");
			c = Float.parseFloat(a);
			
			if (c > saldo)
			{
				s = JOptionPane.showInputDialog("Voce possui emprestimo" + (salario + (salario * 0.05)));
				d = Float.parseFloat(s);
			}
				//if (s.equals(s)) {
					
			//OptionPane.showMessageDialog(null,"Saque autorizado, se saldo atual �: " + ((saldo - c) + s) );
				//}
			{
				JOptionPane.showMessageDialog(null,"Saldo Insulficiente!\n Emprestimo de " + (salario + (salario * 0.05)));
			}
			{
				JOptionPane.showMessageDialog(null,"Saque autorizado, se saldo atual �: " + (saldo - c) );
			}
	}
	

