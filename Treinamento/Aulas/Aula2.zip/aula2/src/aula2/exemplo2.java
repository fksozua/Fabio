package aula2;

//Trabalhando com incremento e decremento

public class exemplo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int x=10;
		
		/*qx++; // x=x+1;
		System.out.println(x);
		
		x--;	
		System.out.println(x);
		
		++x;
		System.out.println(x);
		
		--x;
		System.out.println(x);*/
		
		x++;
		++x;
		System.out.print(x);
	
	}

}
