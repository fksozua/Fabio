package aula2;

//trabalhando com casting

public class exemplo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*int x,y,z;
		
		x=10;
		y=6;
		z=3;*/
		
		
		int x = 10;
		int y = 6;
		int z = 3;
		
		double a = 3;
		double b = 1.0;
		
		double res = (double)x/y;

		System.out.print("O valor da divis�o de x e z � " + res);
	}

}
