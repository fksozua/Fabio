package aula1;

// exercicio Calculadora

public class exemplo3 {

	public static void main(String[] args) {
		
		int n1;
		int n2;
		int soma;
		int sub;
		int mult;
		int div;
	
		n1=10;
		n2=10;
		
		soma=n1+n2;
		sub=n1-n2;
		mult=n1*n2;
		div=n1/n2;
		
		System.out.println("Soma = " + soma);
		System.out.println("Subtra��o = " + sub);
		System.out.println("Multiplica��o = " + mult);
		System.out.println("Divis�o = " + div);
		

	}

}
