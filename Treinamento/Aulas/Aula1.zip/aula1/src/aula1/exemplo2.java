package aula1;

public class exemplo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
