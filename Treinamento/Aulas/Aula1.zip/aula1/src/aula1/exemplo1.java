package aula1;

//Exemplo 1

public class exemplo1 {

	public static void main(String[] args) {
		System.out.println("Primeiro teste de mensagem");
	}

}
