package aula3;

// tabuaba de 10 utilizando a estrutura de repeti��o For

public class exemploFor3 {

	public static void main(String[] args) {
		
		int tab=10;
        for(int i=1;i<11;i++) {
            System.out.println(tab+" * "+i+" = "+tab*i);
        }
		
		
		/*int i;
		int b=10;
		int res;
	
		for (int i=1;i<0;i++) {
			//res = (b*i);
			
			System.out.println(b*i);*/
			
			}

	}
