package aula3;

import java.util.Scanner;

public class exercicio4 {
	
	public static void main(String[] args) {
		String numero;
		double n1, n2, media=0,res=0, x=0, mediaAlunos=0;
		
		Scanner ler = new Scanner(System.in);
			
		while (n1<=10) {
						
			System.out.println(" Digite o numero = ");
			numero=ler.next();
					
		}
		{
			System.out.println("Media de Notas" + res + "\n alunos" + x);
			
		}

	}

}

