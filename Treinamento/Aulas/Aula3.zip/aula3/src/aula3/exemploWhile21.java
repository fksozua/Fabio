package aula3;

public class exemploWhile21 {

	public static void main(String[] args) {
		
		int numero=0;
		
		while (numero<10) {
			System.out.println("x = " + numero);
			
			numero++;
		}
		

	}

}
