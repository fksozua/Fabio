package aula3;

public class exemploFor1 {

	public static void main(String[] args) {
		
		for(int i=0;i<10;i=i+1) { 
// colocar na declara��o do escopo int i // (i=0;i<0;i++)
		System.out.println("ola!");
		
		}

	}

}
