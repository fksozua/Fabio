package aula3;

// exemplo de estrutura de Repeti��o

public class exemploWhile1 {
	
	public static void main(String[] args) {
		
		int idade=15;
		
		while (idade<=18) {
		
			System.out.println(idade);
			//idade=idade+1;
			
			idade++;//exemplo incremento
		}

	}

}
