package aula3;

import java.util.Scanner;

public class exercicio2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String aluno;
		double idade=0;
		
		Scanner ler = new Scanner(System.in);
			
		while (idade99) {
						
			
			System.out.println(" Digite a idade = ");
			idade=ler.nextInt();
			
		}
		{
			System.out.println("Finalizado");
			
		}

	}

}
