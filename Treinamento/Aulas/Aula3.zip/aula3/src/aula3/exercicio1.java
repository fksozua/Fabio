package aula3;

import java.util.Scanner;

public class exercicio1 {

	public static void main(String[] args) {

		int i;
		
		for (i=0; i<0; i++) {
			
			if (i % 3 == 0) {
				System.out.println(-i);
			}
			else {
				System.out.println(i);
			}
		}
	}
}