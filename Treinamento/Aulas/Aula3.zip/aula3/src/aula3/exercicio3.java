package aula3;

public class exercicio3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		res=0;
		i=0;
		media=0;
		count=0;

		for (i=10;i<=100;i=1) {
			res = (res+i);
		}
		media=(res/91);
		System.out.println(media)
	}

}
