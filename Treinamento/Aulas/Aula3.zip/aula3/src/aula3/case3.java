package aula3;

import java.util.Scanner;

public class case3 {

	public static void main(String[] args) {


		System.out.println("<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>");
		System.out.println("<<<<<<<<<CAIXA ELETR�NICO>>>>>>>>>>>>>");
		System.out.println("<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>");
		System.out.println("--------------------------------------");
		System.out.println("TELA DE CADASTRO INICIAL              ");
		System.out.println("Nome: Fabio                           ");
		System.out.println("Valor inicial em conta:1000           ");
		

	}

}
